﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace StockMarket
{
    public class Investor
    {
        private List<Stock> portfolio;
        private string fullName;
        private string emailAdress;
        private decimal moneyToInvest;
        private string brokerName;

        public List<Stock> Portfolio { get => portfolio; set => portfolio = value; }
        public string FullName { get => fullName; set => fullName = value; }
        public string EmailAdress { get => emailAdress; set => emailAdress = value; }
        public decimal MoneyToInvest { get => moneyToInvest; set => moneyToInvest = value; }
        public string BrokerName { get => brokerName; set => brokerName = value; }
        public Investor(string fullName, string emailAdress, decimal moneyToInvest, string brokerName)
        {
            this.Portfolio = new List<Stock>();
            this.FullName = fullName;
            this.EmailAdress = emailAdress;
            this.MoneyToInvest = moneyToInvest;
            this.BrokerName = brokerName;
        }
        public int Count
        {
            get => this.portfolio.Count;
        } 


        public void BuyStock(Stock stock)
        {
            if (stock.MarketCapitalization > 10000)
            {
                if (this.MoneyToInvest >= stock.PricePerShare)
                {
                    this.portfolio.Add(stock);
                    this.MoneyToInvest -= stock.PricePerShare;
                }
            }
        }

        public string SellStock(string companyName, decimal sellPrice)
        {
            var sellingStock = this.portfolio.Find(x => x.CompanyName == companyName);
            if (sellingStock == null)
                return $"{sellingStock.CompanyName} does not exist.";
            else
            {
                if (sellingStock.PricePerShare > sellPrice)
                    return $"Cannot sell {sellingStock.CompanyName}.";
                else
                {
                    this.portfolio.Remove(sellingStock);
                    this.MoneyToInvest += sellPrice;
                    return $"{sellingStock.CompanyName} was sold.";
                }
            }
        }
        public Stock FindStock(string companyName)
        {
            Stock findStock = this.portfolio.FirstOrDefault(x => x.CompanyName == companyName);
            if (findStock == null)
                return null;
            else
                return findStock;

        }
        public Stock FindBiggestCompany()
        {
            if (this.portfolio.Count == 0)
            return null;
            else
            {
                var findStock = this.portfolio.Max(x => x.MarketCapitalization);
                Stock theBiggestCompany = this.portfolio.FirstOrDefault(x => x.MarketCapitalization == findStock);
                return theBiggestCompany;
            }
        }
        public string InvestorInformation()
        {
            return $"The investor {this.FullName} with a broker {this.BrokerName} has stocks:" + Environment.NewLine +
            $"{String.Join(Environment.NewLine, this.portfolio)}";
        }

    }
}
