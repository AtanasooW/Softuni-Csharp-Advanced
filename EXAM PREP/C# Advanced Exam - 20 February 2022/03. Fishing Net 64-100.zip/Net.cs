﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FishingNet
{
    public class Net
    {
        string material;
        int capasity;
        List<Fish> fish;
        public int Count => fish.Count;
        public IReadOnlyCollection<Fish> Fish => (IReadOnlyCollection<Fish>)this.fish;

        public Net(string Material, int capasity)
        {
            this.material = Material;
            this.capasity = capasity;
            this.fish = new List<Fish>();
            
        }

        public string Report()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Into the {this.material}:");

            foreach (var item in fish.OrderByDescending(x => x.Lenght))
            {
                sb.AppendLine(item.ToString());
            }
            return sb.ToString().TrimEnd();

        }
        public Fish GetBiggestFish()
        {
            double TheLongestFish = fish.Max(fish => fish.Lenght);
            Fish TheBiggestFihs = fish.FirstOrDefault(fish => fish.Lenght == TheLongestFish);
            return TheBiggestFihs;
        }
        public Fish GetFish(string fishType)
        {
            var fish = this.fish.FirstOrDefault(e => e.FishType == fishType);
            return fish;
        }
        public bool ReleaseFish(double weight)
        {
            var fishes = this.fish.FirstOrDefault(e => e.Weight == weight);
            if (fishes != null)
                this.fish.Remove(fishes);
                return true;

            return false;
        }
        public string AddFish(Fish Fish)
        {
            if (Count + 1 < capasity)
            {
                if (string.IsNullOrWhiteSpace(Fish.FishType) || Fish.Lenght <= 0 || Fish.Weight <= 0)
                {
                    return "Invalid fish.";
                }
                this.fish.Add(Fish);
                return $"Successfully added {Fish.FishType} to the fishing net.";
            }
            return "Fishing net is Full.";
        }
    }
}
