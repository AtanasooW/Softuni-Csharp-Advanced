﻿using System;
using System.Collections.Generic;

namespace DefiningClasses
{
    internal class StartUp
    {
        static void Main(string[] args)
        {
            List<Car> cars = new List<Car>();
           int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                string[] cmd = Console.ReadLine().Split();
                var car = new Car(cmd[0], double.Parse(cmd[1]), double.Parse(cmd[2]));
                cars.Add(car);
            }
            while (true)
            {
                string[] cmd = Console.ReadLine().Split();
                if (cmd[0] == "End")
                    break;
                else
                {
                    foreach (var item in cars)
                    {
                        if (item.Model == cmd[1])
                        {
                            item.Drive(double.Parse(cmd[2]));
                        }
                    }
                }
            }
            foreach (var item in cars)
            {
                Console.WriteLine($"{item.Model} {item.FuelAmount:F2} {item.TravelledDistance}");
            }
        }
    }
}
