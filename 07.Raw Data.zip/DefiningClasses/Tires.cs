﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DefiningClasses
{
    public class Tires
    {
        public int Age{ get; set; }
        public double Pressure{ get; set; }

        public Tires(double pressure,int age)
        {
            Pressure = pressure;
            Age = age;
        }
    }
}
