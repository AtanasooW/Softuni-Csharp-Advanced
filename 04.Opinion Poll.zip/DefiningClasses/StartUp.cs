﻿using System;
using System.Linq;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            var family = new Family();
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                string[] cmd = Console.ReadLine().Split();
                family.AddMember(cmd[0], int.Parse(cmd[1]));
            }
            var list = family.GetOldestMember();
            foreach (var item in list.OrderBy(x => x.Name))
            {
                Console.WriteLine(item.Name + " - " + item.Age );
            }
        }
    }
}
