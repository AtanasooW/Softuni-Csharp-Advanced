﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            var person3 = new Person();
            var person2 = new Person(18);
            var person1 = new Person("Peter", 20);
        }
    }
}
